package p.services;

public interface MyService {

	String ask(String question);
}
